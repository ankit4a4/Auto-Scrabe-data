const axios = require("axios");
const config = require("../config");

// Once a provider's free quota runs out (402/429 response), we mark it
// "exhausted" for the rest of this server session so we stop wasting
// requests on it and move straight to the next provider each time.
const exhausted = {
  hunter: false,
  apollo: false,
  lusha: false,
  rocketreach: false,
};

function isQuotaError(err) {
  const status = err.response?.status;
  return status === 402 || status === 429 || status === 403;
}

// ---------------------------------------------------------------------------
// 1) Hunter.io - EMAIL ONLY (Hunter's API does not provide phone numbers at
//    any plan tier). Uses the Email Finder endpoint: full_name + company.
// ---------------------------------------------------------------------------
async function tryHunter(company) {
  if (!config.hunterApiKey || exhausted.hunter) return { phone: null, email: null };
  if (!company.ownerNames?.[0]) return { phone: null, email: null }; // Hunter needs a person's name

  try {
    const res = await axios.get("https://api.hunter.io/v2/email-finder", {
      params: {
        full_name: company.ownerNames[0],
        company: company.businessName,
        api_key: config.hunterApiKey,
      },
      timeout: 15000,
    });
    const email = res.data?.data?.email || null;
    return { phone: null, email }; // Hunter never returns phone numbers
  } catch (err) {
    if (isQuotaError(err)) exhausted.hunter = true;
    return { phone: null, email: null };
  }
}

// ---------------------------------------------------------------------------
// 2) Apollo.io - People Enrichment endpoint. Can return both email and
//    phone synchronously with reveal_personal_emails / reveal_phone_number.
//    (Apollo also offers a more thorough async "waterfall" phone lookup via
//    webhook, which needs a public webhook URL - skipped here for simplicity.)
// ---------------------------------------------------------------------------
async function tryApollo(company) {
  if (!config.apolloApiKey || exhausted.apollo) return { phone: null, email: null };

  const nameParts = (company.ownerNames?.[0] || "").split(" ");
  const first_name = nameParts[0] || undefined;
  const last_name = nameParts.slice(1).join(" ") || undefined;

  try {
    const res = await axios.post(
      "https://api.apollo.io/api/v1/people/match",
      {
        first_name,
        last_name,
        organization_name: company.businessName,
        reveal_personal_emails: true,
        reveal_phone_number: true,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": config.apolloApiKey,
        },
        timeout: 15000,
      }
    );
    const person = res.data?.person;
    return {
      phone: person?.phone_numbers?.[0]?.raw_number || null,
      email: person?.email || null,
    };
  } catch (err) {
    if (isQuotaError(err)) exhausted.apollo = true;
    return { phone: null, email: null };
  }
}

// ---------------------------------------------------------------------------
// 3) Lusha - Person API v2. Simpler firstName/lastName/companyName lookup
//    (v2 is marked "still operational" by Lusha - if it's deprecated on
//    your account, this call will just fail gracefully and get skipped).
// ---------------------------------------------------------------------------
async function tryLusha(company) {
  if (!config.lushaApiKey || exhausted.lusha) return { phone: null, email: null };

  const nameParts = (company.ownerNames?.[0] || "").split(" ");
  const firstName = nameParts[0] || undefined;
  const lastName = nameParts.slice(1).join(" ") || undefined;

  try {
    const res = await axios.get("https://api.lusha.com/v2/person", {
      params: {
        firstName,
        lastName,
        companyName: company.businessName,
      },
      headers: { api_key: config.lushaApiKey },
      timeout: 15000,
    });
    const data = res.data?.data;
    return {
      phone: data?.phoneNumbers?.[0]?.number || null,
      email: data?.emailAddresses?.[0]?.email || null,
    };
  } catch (err) {
    if (isQuotaError(err)) exhausted.lusha = true;
    return { phone: null, email: null };
  }
}

// ---------------------------------------------------------------------------
// 4) RocketReach - Person Lookup endpoint. name + current_employer.
// ---------------------------------------------------------------------------
async function tryRocketReach(company) {
  if (!config.rocketreachApiKey || exhausted.rocketreach) return { phone: null, email: null };
  if (!company.ownerNames?.[0]) return { phone: null, email: null };

  try {
    const res = await axios.get("https://api.rocketreach.co/api/v2/person/lookup", {
      params: {
        name: company.ownerNames[0],
        current_employer: company.businessName,
      },
      headers: { "Api-Key": config.rocketreachApiKey },
      timeout: 15000,
    });
    const emails = res.data?.emails;
    const phones = res.data?.phones;
    return {
      phone: phones?.[0]?.number || null,
      email: emails?.[0]?.email || null,
    };
  } catch (err) {
    if (isQuotaError(err)) exhausted.rocketreach = true;
    return { phone: null, email: null };
  }
}

/**
 * Tries each configured paid provider IN ORDER (Hunter -> Apollo -> Lusha ->
 * RocketReach), stopping as soon as BOTH phone and email are found. A
 * provider with no API key configured, or whose free quota has already run
 * out this session, is skipped automatically - no code changes needed, just
 * add/remove keys in .env.
 *
 * This only runs for whatever the free DuckDuckGo search (contactEnrichment.js)
 * couldn't find - it's a fallback on top of a fallback, all best-effort.
 */
async function tryPaidProviders(company) {
  let phone = company.phone || null;
  let email = company.email || null;

  const providers = [tryHunter, tryApollo, tryLusha, tryRocketReach];

  for (const provider of providers) {
    if (phone && email) break; // both already found, no need to try more
    const result = await provider({ ...company, phone, email });
    phone = phone || result.phone;
    email = email || result.email;
  }

  return { phone, email };
}

module.exports = { tryPaidProviders };
